using System.Data;
using System.Text.Json;
using EduConnect.Mvc.Areas.KetNoi.ViewModels;
using EduConnect.Mvc.Data;
using EduConnect.Mvc.Infrastructure;
using EduConnect.Mvc.Models;
using Microsoft.EntityFrameworkCore;
namespace EduConnect.Mvc.Areas.KetNoi.Services;

public sealed partial class KetNoiService(AppDbContext db, INguoiDungHienTaiService current, ThongBaoService notices, ILienHeStore? lienHeStore = null, IKetNoiStore? store = null, TimeProvider? timeProvider = null) : IKetNoiService
{
    private readonly ILienHeStore invitations = lienHeStore ?? new EfLienHeStore(db, notices);
    private readonly IKetNoiStore persistence = store ?? new EfKetNoiStore(db);
    private readonly TimeProvider clock = timeProvider ?? TimeProvider.System;

    public async Task<Dictionary<Guid, LopHoc>> LopTheoLienHeAsync()
    {
        var user = await current.HienTaiAsync();
        var rows = await (from lop in db.Set<LopHoc>().AsNoTracking()
                          join request in db.Set<YeuCauKetNoiLopHoc>() on lop.YeuCauKetNoiId equals request.Id
                          where lop.TrangThai == "DangHoatDong"
                              && (lop.GiaSuId == user.Id || lop.BenHocId == user.Id)
                          orderby lop.Id
                          select new { request.LienHeId, Lop = lop }).ToListAsync();
        return rows.GroupBy(x => x.LienHeId).ToDictionary(group => group.Key, group => group.First().Lop);
    }

    private async Task KiemTraLopDangHoatDongAsync(Guid contact, CancellationToken huy)
    {
        await persistence.LockContactAsync(contact, huy);
        var connected = await persistence.HasActiveClassAsync(contact, huy);
        Rules.Check(!connected, "Hai bên đã có lớp đang hoạt động. Hãy mở lớp học để tiếp tục.", 409);
    }

    public async Task<Dictionary<Guid, Guid>> HoiThoaiLienHeAsync()
    {
        var u = await current.HienTaiAsync();
        return await db.Set<CuocHoiThoai>().Where(c => c.LoaiHoiThoai == "TruocKetNoi" && c.LienHeId != null && (c.GiaSuId == u.Id || c.BenHocId == u.Id) && db.Set<YeuCauLienHe>().Any(h => h.Id == c.LienHeId && h.TrangThai == "ChapNhan")).ToDictionaryAsync(c => c.LienHeId!.Value, c => c.Id);
    }
    public async Task<Guid?> HoiThoaiAsync(Guid id)
    {
        var u = await current.HienTaiAsync();
        return await db.Set<CuocHoiThoai>().Where(c => c.LienHeId == id && c.LoaiHoiThoai == "TruocKetNoi" && (c.GiaSuId == u.Id || c.BenHocId == u.Id) && db.Set<YeuCauLienHe>().Any(h => h.Id == id && h.TrangThai == "ChapNhan")).Select(c => (Guid?)c.Id).FirstOrDefaultAsync();
    }
    public async Task<(List<YeuCauLienHe> Contacts, List<YeuCauKetNoiLopHoc> Requests)> LayAsync()
    {
        var u = await current.HienTaiAsync();
        return (await db.Set<YeuCauLienHe>().AsNoTracking().Where(x => x.GiaSuId == u.Id || x.BenHocId == u.Id).OrderByDescending(x => x.GuiLuc).ToListAsync(), await db.Set<YeuCauKetNoiLopHoc>().AsNoTracking().Where(x => x.GiaSuId == u.Id || x.BenHocId == u.Id).OrderByDescending(x => x.GuiLuc).ToListAsync());
    }
    public async Task<YeuCauLienHe?> LienHeVoiAsync(Guid other)
    {
        var u = await current.HienTaiAsync();
        return await db.Set<YeuCauLienHe>().AsNoTracking().Where(x => (x.GiaSuId == u.Id && x.BenHocId == other || x.BenHocId == u.Id && x.GiaSuId == other) && (x.TrangThai == "ChapNhan" || x.TrangThai == "ChoPhanHoi")).FirstOrDefaultAsync();
    }
    public async Task GuiLienHeAsync(GuiLienHeInput m)
    {
        Rules.ValidateInput(m);
        var u = await current.HienTaiAsync();
        var other = await invitations.ReadRecipientAsync(m.DoiTuongId) ?? throw new LoiNghiepVu("Người nhận không tồn tại.");
        Rules.Check(u.Id != other.Id && (u.LoaiNguoi == "GiaSu") != (other.LoaiNguoi == "GiaSu"), "Liên hệ cần một gia sư và một bên học.");
        var tutor = u.LoaiNguoi == "GiaSu" ? u.Id : other.Id;
        var learner = u.LoaiNguoi == "GiaSu" ? other.Id : u.Id;
        await using var tx = await invitations.BeginAsync();
        Rules.Check((u.LoaiNguoi is "GiaSu" or "HocSinh" or "PhuHuynh") && (other.LoaiNguoi is "GiaSu" or "HocSinh" or "PhuHuynh"), "Vai trò không được gửi liên hệ.", 403);
        await invitations.LockProfileAsync(tutor);
        Rules.Check(!await invitations.IsHiddenAsync(tutor),"Hồ sơ hiện đang bị hạn chế tiếp nhận liên hệ mới.",409);
        Rules.Check(await invitations.IsEligibleAsync(tutor), "Hồ sơ gia sư đã ẩn hoặc chưa đủ điều kiện nhận liên hệ mới.", 409);
        Rules.Check(!await invitations.ExistsAsync(tutor, learner), "Hai bên đã liên hệ hoặc đang chờ phản hồi.");
        var id = Guid.NewGuid();
        invitations.AddContact(new YeuCauLienHe { Id = id, GiaSuId = tutor, BenHocId = learner, NguoiGuiId = u.Id, LoiNhan = m.LoiNhan.Trim(), TrangThai = "ChoPhanHoi", GuiLuc = DateTimeOffset.UtcNow });
        invitations.Notify(other.Id, "KetNoi", id, u.HoTen + " gửi yêu cầu liên hệ.");
        await invitations.SaveAsync();
        await tx.CommitAsync();
    }
    public async Task PhanHoiLienHeAsync(Guid id, string action, string version)
    {
        Rules.Check(action is "ChapNhan" or "TuChoi" or "DaRut", "Phản hồi không hợp lệ.");
        var u = await current.HienTaiAsync();
        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        var r = await db.Set<YeuCauLienHe>().SingleOrDefaultAsync(x => x.Id == id && (x.GiaSuId == u.Id || x.BenHocId == u.Id)) ?? throw new LoiNghiepVu("Không có quyền phản hồi.", 403);
        Rules.Check(r.TrangThai == "ChoPhanHoi", "Yêu cầu đã được xử lý.", 409);
        Rules.Check(action == "DaRut" ? r.NguoiGuiId == u.Id : r.NguoiGuiId != u.Id, "Không có quyền phản hồi.", 403);
        Rules.Concurrency(db, r, version);
        r.TrangThai = action;
        if (action != "DaRut")
        {
            r.NguoiPhanHoiId = u.Id;
            r.PhanHoiLuc = DateTimeOffset.UtcNow;
        }
        await db.SaveChangesAsync();
        if (action == "ChapNhan" && !await db.Set<CuocHoiThoai>().AnyAsync(c => c.LienHeId == id && c.LoaiHoiThoai == "TruocKetNoi"))
            db.Add(new CuocHoiThoai { Id = Guid.NewGuid(), LoaiHoiThoai = "TruocKetNoi", GiaSuId = r.GiaSuId, BenHocId = r.BenHocId, LienHeId = id, TaoLuc = DateTimeOffset.UtcNow });
        notices.Tao(u.Id == r.GiaSuId ? r.BenHocId : r.GiaSuId, "KetNoi", id, u.HoTen + ": " + Rules.Label(action) + " liên hệ.");
        await db.SaveChangesAsync();
        await tx.CommitAsync();
    }
    private async Task<YeuCauLienHe> AcceptedAsync(Guid id, bool tutor)
    {
        var u = await current.HienTaiAsync();
        Rules.Check(tutor ? u.LoaiNguoi == "GiaSu" : u.LoaiNguoi != "GiaSu", "Vai trò không được thực hiện thao tác này.", 403);
        return await persistence.SingleAsync<YeuCauLienHe>(x => x.Id == id && x.TrangThai == "ChapNhan" && (tutor ? x.GiaSuId == u.Id : x.BenHocId == u.Id)) ?? throw new LoiNghiepVu("Cần liên hệ được chấp nhận trước.", 403);
    }
    public async Task<Guid> GuiYeuCauAsync(GuiYeuCauInput m, CancellationToken huy = default)
    {
        var c = await AcceptedAsync(m.LienHeId, false);
        var u = await current.HienTaiAsync(huy);
        await using var tx = await persistence.BeginAsync(huy);
        await KiemTraLopDangHoatDongAsync(m.LienHeId, huy);
        await persistence.ExecuteAsync($"EXEC dbo.usp_GuiYeuCauKetNoi @LienHeId={m.LienHeId},@BenHocId={u.Id},@LoiNhan={m.LoiNhan},@NhuCauId={m.NhuCauId}", huy);
        var target = await persistence.LatestRequestIdAsync(m.LienHeId, "ChoGiaSu", huy);
        notices.Tao(c.GiaSuId, "KetNoi", target, "Có yêu cầu kết nối mới.");
        await persistence.SaveAsync(huy);
        await tx.CommitAsync(huy);
        return target;
    }
    public async Task<DeXuatLopViewModel> LayDeXuatAsync(Guid contact, Guid? id)
    {
        await AcceptedAsync(contact, true);
        if (id == null)
            return new()
            {
                LienHeId = contact
            };
        var u = await current.HienTaiAsync();
        var r = await db.Set<YeuCauKetNoiLopHoc>().AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.LienHeId == contact && x.GiaSuId == u.Id) ?? throw new LoiNghiepVu("Không có yêu cầu này.", 404);
        var slots = await db.Set<KhungGioDeXuat>().Where(x => x.YeuCauKetNoiId == id).Select(x => new SlotInput { ThuTrongTuan = x.ThuTrongTuan, GioBatDau = x.GioBatDau, GioKetThuc = x.GioKetThuc }).ToListAsync();
        return new()
        {
            Id = id,
            LienHeId = contact,
            NhuCauId = r.NhuCauId,
            RowVersion = Convert.ToBase64String(r.RowVersion),
            TenLop = r.TenLopDuKien ?? "",
            MonHocId = r.MonHocId ?? 1,
            MucTieu = r.MucTieu ?? "",
            SoBuoiTuan = r.SoBuoiTuan ?? 1,
            ThoiLuongPhut = r.ThoiLuongPhut ?? 90,
            BatDauHocLuc = r.BatDauHocLuc?.ToOffset(TimeSpan.FromHours(7)).DateTime ?? DateTime.Today.AddDays(2),
            HinhThucHoc = r.HinhThucHoc ?? "TrucTuyen",
            DiaDiem = r.DiaDiem,
            HocPhi = r.HocPhi ?? 150000,
            DonViHocPhi = r.DonViHocPhi ?? "VND/Gio",
            LichRanh = slots.Count == 0 ? [new()] : slots
        };
    }
    public async Task<Guid> GuiDeXuatAsync(DeXuatLopViewModel m, CancellationToken huy = default)
    {
        Rules.ValidateInput(m);
        var c = await AcceptedAsync(m.LienHeId, true);
        var u = await current.HienTaiAsync(huy);
        Rules.FeeCheck(m.HocPhi, m.DonViHocPhi);
        Rules.Check(m.HocPhi > 0, "Nhập học phí lớn hơn 0.", field: "HocPhi");
        Rules.Slots(m.LichRanh);
        Rules.Check(m.LichRanh.Count == m.SoBuoiTuan && m.LichRanh.All(s => (s.GioKetThuc - s.GioBatDau).TotalMinutes == m.ThoiLuongPhut), "Số khung giờ và thời lượng phải khớp điều kiện lớp.");
        Rules.Check(Rules.Local(m.BatDauHocLuc) > clock.GetUtcNow(), "Ngày bắt đầu phải ở tương lai.");
        Rules.Check(m.HinhThucHoc != "TrucTiep" || !string.IsNullOrWhiteSpace(m.DiaDiem), "Nhập địa điểm học trực tiếp.");
        if (m.NhuCauId != null)
            Rules.Check(await persistence.AnyAsync<NhuCauHoc>(n => n.Id == m.NhuCauId && n.ChuSoHuuId == c.BenHocId && n.LoaiNhuCau == "TimGiaSu" && n.TrangThai == "DangMo"), "Nhu cầu phải thuộc bên học và đang mở.");
        var json = JsonSerializer.Serialize(m.LichRanh);
        var start = Rules.Local(m.BatDauHocLuc);
        var rv = Rules.SqlVersion(m.Id == null ? null : m.RowVersion);
        await using var tx = await persistence.BeginAsync(huy);
        await KiemTraLopDangHoatDongAsync(m.LienHeId, huy);
        await persistence.ExecuteAsync($"EXEC dbo.usp_GuiDeXuatLop @LienHeId={m.LienHeId},@GiaSuId={u.Id},@TenLop={m.TenLop},@MonHocId={m.MonHocId},@MucTieu={m.MucTieu},@SoBuoiTuan={m.SoBuoiTuan},@ThoiLuongPhut={m.ThoiLuongPhut},@BatDauHocLuc={start},@HinhThucHoc={m.HinhThucHoc},@HocPhi={m.HocPhi},@DonViHocPhi={m.DonViHocPhi},@KhungGioJson={json},@DiaDiem={m.DiaDiem},@NhuCauId={m.NhuCauId},@YeuCauId={m.Id},@RowVersionCu={rv}", huy);
        var target = await persistence.LatestRequestIdAsync(m.LienHeId, "ChoBenHoc", huy);
        notices.Tao(c.BenHocId, "KetNoi", target, "Gia sư gửi đề xuất lớp. Hãy xem lại toàn bộ điều kiện trước khi xác nhận.");
        await persistence.SaveAsync(huy);
        await tx.CommitAsync(huy);
        return target;
    }
    public async Task<YeuCauKetNoiLopHoc> ChiTietAsync(Guid id)
    {
        var u = await current.HienTaiAsync();
        return await persistence.SingleAsync<YeuCauKetNoiLopHoc>(x => x.Id == id && (x.GiaSuId == u.Id || x.BenHocId == u.Id), tracking: false) ?? throw new LoiNghiepVu("Không tìm thấy yêu cầu.", 404);
    }
    public Task<List<KhungGioDeXuat>> KhungAsync(Guid id) => db.Set<KhungGioDeXuat>().Where(x => x.YeuCauKetNoiId == id).ToListAsync();
    public Task<Guid> ChapNhanAsync(Guid id, string version) => ChapNhanDeXuatAsync(id, version);

    public async Task<Guid> ChapNhanDeXuatAsync(Guid id, string version, CancellationToken huy = default)
    {
        var u = await current.HienTaiAsync(huy);
        await using var tx = await persistence.BeginAsync(huy);
        var resource = "EduConnect:ChapNhan:" + id;
        await persistence.ExecuteAsync($"DECLARE @Result int; EXEC @Result=sys.sp_getapplock @Resource={resource}, @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=15000; IF @Result<0 THROW 51152,N'Yêu cầu đang được xử lý, hãy thử lại.',1;", huy);
        var r = await ChiTietAsync(id);
        Rules.Check(r.BenHocId == u.Id, "Chỉ bên học được chấp nhận đề xuất.", 403);
        if (r.TrangThai == "DaChapNhan")
            return await persistence.ClassIdForRequestAsync(id);
        var rv = Rules.Version(version);
        await persistence.ExecuteAsync($"EXEC dbo.usp_ChapNhanDeXuatTaoLop @YeuCauId={id},@BenHocId={u.Id},@RowVersionCu={rv}", huy);
        var c = await persistence.RequiredAsync<LopHoc>(x => x.YeuCauKetNoiId == id);
        notices.Tao(r.GiaSuId, "KetNoi", c.Id, "Đề xuất được chấp nhận; lớp học đã được tạo.");
        await persistence.SaveAsync(huy);
        await tx.CommitAsync(huy);
        return c.Id;
    }
    public async Task PhanHoiAsync(Guid id, string action, string version, CancellationToken huy = default)
    {
        Rules.Check(action is "DaRut" or "TuChoi", "Phản hồi không hợp lệ.");
        var u = await current.HienTaiAsync();
        var r = await persistence.SingleAsync<YeuCauKetNoiLopHoc>(x => x.Id == id && (x.GiaSuId == u.Id || x.BenHocId == u.Id)) ?? throw new LoiNghiepVu("Không có quyền.", 403);
        Rules.Check(r.TrangThai is "ChoGiaSu" or "ChoBenHoc" && r.HetHanLuc > clock.GetUtcNow(), "Yêu cầu đã hết hiệu lực.", 409);
        var sender = r.TrangThai == "ChoBenHoc" ? r.GiaSuId : r.NguoiGuiId;
        Rules.Check(action == "DaRut" ? sender == u.Id : sender != u.Id, "Không có quyền phản hồi.", 403);
        persistence.SetVersion(r, version);
        r.TrangThai = action;
        await using var tx = await persistence.BeginAsync(huy);
        notices.Tao(u.Id == r.GiaSuId ? r.BenHocId : r.GiaSuId, "KetNoi", id, "Yêu cầu kết nối: " + Rules.Label(action));
        await persistence.SaveAsync(huy);
        await tx.CommitAsync(huy);
    }

    public Task TuChoiDeXuatAsync(Guid maYeuCau, string rowVersion) =>
        PhanHoiAsync(maYeuCau, "TuChoi", rowVersion);

    public Task RutYeuCauAsync(Guid maYeuCau, string rowVersion) =>
        PhanHoiAsync(maYeuCau, "DaRut", rowVersion);
}
