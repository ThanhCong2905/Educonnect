from pathlib import Path
import json,re,hashlib,zipfile,difflib,shutil,xml.etree.ElementTree as ET
from datetime import datetime

repo=Path(r'C:\Khóa luận TN\Educonnect')
out=Path('outputs/07-Service-YeuCau-DeXuat-Lop-Unit');out.mkdir(parents=True,exist_ok=True)
trx=Path('work/group07-run/Service-YeuCau-DeXuat-Lop-Unit.trx')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
root=ET.parse(trx).getroot()
cases=json.loads(Path('work/group07-cases.json').read_text(encoding='utf-8'))
results={}
for r in root.findall('.//t:UnitTestResult',ns):
    id='UT-'+re.search(r'UT_(\d+)',r.attrib['testName']).group(1)
    stdout=r.findtext('t:Output/t:StdOut','',ns)
    observations=[json.loads(x.split('OBSERVATION_JSON:',1)[1]) for x in stdout.splitlines() if 'OBSERVATION_JSON:' in x]
    results[id]={'outcome':r.attrib['outcome'],'testName':r.attrib['testName'],'duration':r.attrib.get('duration'),
      'error':r.findtext('t:Output/t:ErrorInfo/t:Message','',ns),'stack':r.findtext('t:Output/t:ErrorInfo/t:StackTrace','',ns),'observations':observations}
assert len(results)==51 and set(results)=={c['id'] for c in cases}
assert sum(len(r['observations']) for r in results.values())==123

def line(path,text):
    lines=(repo/path).read_text(encoding='utf-8-sig').splitlines()
    return f'{path}:{next(i+1 for i,s in enumerate(lines) if text in s)}'
main='Areas/KetNoi/Services/KetNoiService.cs';wrapper='Areas/KetNoi/Services/KetNoiService.YeuCau.cs'
def source(n):
    if n<=174:return line('Areas/KetNoi/Services/KetNoiService.KetThuc.cs','private async Task KiemTraNguoiThucHienAsync')
    if n<=180:return line(main,'private async Task<YeuCauLienHe> AcceptedAsync')
    if n<=182:return line(main,'public async Task<Guid> GuiYeuCauAsync')
    if n<=192:return line(main,'public async Task<Guid> GuiDeXuatAsync')
    if n<=201:return line('Infrastructure/KetQua.cs','public static async Task<KetQua<T>> ThucHienAsync')
    if n<=206:return line(main,'public async Task<Guid> ChapNhanDeXuatAsync')
    if n>=219:return line(wrapper,'public Task<KetQua> TuChoiDeXuatAsync')
    return line(main,'public async Task PhanHoiAsync')

def action(n):
    if 175<=n<=180:return 'AcceptedAsync(Guid, bool, Guid, CancellationToken) — helper private thực tế trong code'
    if n in (171,176) or 183<=n<=192 or 196<=n<=198:return 'GuiDeXuatAsync(DeXuatLopViewModel, Guid, CancellationToken)'
    if n==172 or 199<=n<=206:return 'ChapNhanDeXuatAsync(Guid, byte[], Guid, CancellationToken)'
    if n==173 or 207<=n<=212 or n>=219:return 'TuChoiDeXuatAsync(Guid, string, byte[], Guid, CancellationToken)'
    if n==174 or 213<=n<=218:return 'RutYeuCauAsync(Guid, byte[], Guid, CancellationToken)'
    return 'GuiYeuCauAsync(GuiYeuCauViewModel, Guid, CancellationToken)'

def desc(o):
    a=o['actual']
    s=f"Ngoại lệ thoát ra: {o['exception']}: {o['exceptionMessage']}." if o['exception'] else f"KetQua.ThanhCong={str(o['success']).lower()}, mã={o['actualStatus']}, thông điệp={json.dumps(o['message'],ensure_ascii=False)}."
    if o['data']:s+=f" DuLieu={o['data']}."
    if o['acceptedId']:s+=f" Liên hệ trả về={o['acceptedId']}."
    s+=f" Lệnh nghiệp vụ={sum('sp_getapplock' not in x['Format'] for x in a['commands'])}; Save={a['Saves']}; Commit={a['Commits']}; notice={len(a['notices'])}; outbox={a['events']}; trạng thái đối tượng theo dõi={a['requestState']}."
    return s

def assertions(n):
    if n<=174:return 'KetQua lỗi 403; không lệnh ghi, Save, Commit, notice hoặc outbox; trạng thái yêu cầu giữ nguyên.'
    if n<=179:return 'Mã lỗi đúng bảng; không lệnh ghi, Save, Commit, notice/outbox; trạng thái yêu cầu giữ nguyên.'
    if n==180:return 'Thành công; DuLieu là chính liên hệ LH1 đã đọc; không có thao tác ghi.'
    if n==181:return 'Phân giải đúng cặp G/H và token một lần; LienHeId của input, khóa liên hệ và đối số lệnh đều là LH1; trả YC1; thông báo đúng gia sư; Save trước Commit.'
    if n==182:return 'Trả YC1; đúng mã liên hệ/người gửi/lời nhắn/nhu cầu; một lệnh nghiệp vụ; một notice/outbox liên kết cùng MaSuKien; nhận G, target YC1; Event/Notice trước Save trước Commit.'
    if 183<=n<=190:return 'KetQua lỗi 400; không lệnh procedure, Save, Commit, notice/outbox; trạng thái yêu cầu giữ nguyên.'
    if n in (191,192):return 'Một lệnh đề xuất; JSON bằng dữ liệu lịch đầu vào; đúng LH1/G; @YeuCauId null và SQL parameter RV=DBNull khi tạo, hoặc YC1/RV1 đúng 8 byte khi cập nhật; trả YC1; thông báo H/YC1; Save trước Commit.'
    if n in (193,196,199):return 'DbUpdateConcurrencyException được chuyển thành lỗi 409; một lệnh nghiệp vụ đã được thử; không Save, Commit hoặc notice; không báo thành công.'
    if n in (194,197,200):return 'Đúng instance InvalidOperationException thoát lên caller; không Commit, không notice.'
    if n in (195,198,201):return '25 mã 51130–51154 đều có status theo bảng kỳ vọng độc lập: 51133/51140/51151→403; 51132/51138/51139/51141/51144/51145/51152→409; còn lại→400. Mỗi mã fixture riêng; không Commit/Save/notice.'
    if n in (202,207,213):return 'Byte[7] bị từ chối với mã 400; không lệnh nghiệp vụ/Save/Commit/notice/outbox; trạng thái giữ nguyên.'
    if n==203:return 'Nhận SqlException 51152 từ cổng thực thi khóa → KetQua 409; không lệnh tạo lớp, Save, Commit hoặc notice/outbox. Kiểm phần ánh xạ ở service, không kiểm kết quả âm thực tế của sp_getapplock.'
    if n==204:return 'Request được đọc sau bước khóa; actor là gia sư G, BenHocId=H khác actor; lỗi 403, không gọi lệnh tạo lớp/Save/Commit/notice.'
    if n==205:return 'Khóa và đọc lại yêu cầu DaChapNhan; trả lớp C1 có sẵn; không gọi lệnh tạo mới, Save, Commit hoặc notice/outbox.'
    if n==206:return 'Hai lệnh gồm khóa ứng dụng rồi đúng một lệnh tạo lớp; đối số YC1 và RV1 đúng; đọc lại C1; trả C1; notice G/target C1; outbox liên kết notice; Save trước Commit.'
    if n in (208,209,214,215):return 'Lỗi 409, không ghi đè trạng thái, không lệnh nghiệp vụ, Save/Commit/notice/outbox.'
    if n in (210,216):return 'Sai phía thao tác trả 403; không sửa trạng thái, không Save/Commit/notice/outbox.'
    if n in (211,217):return 'RV0 được chuyển Base64 và đặt làm original version; Save giả lập ném concurrency; KetQua 409; không Commit, không gọi lệnh tạo lớp. Đối tượng trong RAM có thể đã đổi trạng thái; unit không chứng minh rollback CSDL.'
    if n in (212,218,219):return 'Trạng thái TuChoi/DaRut đúng thao tác; version RV1; thông báo tới đối tác, target YC1; đúng một Save và Commit; outbox/notice được thêm trước Save; không lệnh tạo lớp.'
    return 'Lý do 2001 ký tự trả 400; trạng thái giữ nguyên; không Save, Commit, lệnh nghiệp vụ, notice/outbox.'

failure175={
 'category':'Sai mã lỗi đối với liên hệ không tồn tại',
 'differences':['Kỳ vọng KetQua lỗi 404, thực tế lỗi 403.','Thông điệp thực tế “Cần liên hệ được chấp nhận trước.” gộp tình huống không tồn tại với chưa được chấp nhận hoặc sai phía.','Không ghi dữ liệu/commit: đạt; sai lệch ở mã phản hồi, không phải đã ghi nhầm dữ liệu.'],
 'cause':'AcceptedAsync dùng một truy vấn kết hợp Id + TrangThai==ChapNhan + bên tham gia. Khi kết quả null, mọi nguyên nhân đều đi vào cùng LoiNghiepVu(...,403). Nhánh không tồn tại không được phân biệt thành 404 như TC.',
 'location':line(main,'return await persistence.SingleAsync<YeuCauLienHe>'),
 'impact':'Caller không phân biệt được liên hệ không tồn tại với liên hệ không đủ quyền. Đây là sai lệch hợp đồng lỗi của TC; không phải lỗi crash hoặc thao tác ghi.',
 'fix':'Đọc theo Id trước; nếu null trả 404; sau đó kiểm bên tham gia/trạng thái và trả 403. Chỉ đổi sau khi chốt yêu cầu 404 trong thiết kế, vì lựa chọn gộp 403 có thể là chủ ý hạn chế lộ thông tin.'}
failure179={
 'category':'Thiếu kiểm trạng thái khóa tài khoản ở helper AcceptedAsync',
 'differences':['Kỳ vọng KetQua lỗi 403, thực tế ThanhCong=true, mã 200, DuLieu=LH1.','Fixture có tài khoản gia sư G.TrangThai=BiKhoa, liên hệ LH1 vẫn ChapNhan và actor H đúng bên học.','AccountReads=0: helper không hỏi trạng thái tài khoản của hai phía.','Helper này không ghi dữ liệu: Save/Commit/notice/outbox đều 0. Không kết luận từ unit này rằng toàn bộ hệ thống hoặc procedure cũng bỏ qua trạng thái khóa.'],
 'cause':'AcceptedAsync chỉ kiểm vai trò actor, liên hệ đã ChapNhan và Id bên tham gia. NguoiThamGia không chứa TrangThai tài khoản; helper không đọc TaiKhoan hay gọi cổng kiểm trạng thái hai phía. Trạng thái BiKhoa trong nguồn giả lập không được code sử dụng.',
 'location':line(main,'private async Task<YeuCauLienHe> AcceptedAsync'),
 'impact':'Điều kiện “không tài khoản bị khóa” của bộ TC chưa được thực thi tại helper service này. Cần kiểm riêng các lớp bảo vệ khác trước khi kết luận mức ảnh hưởng khi chạy HTTP/SQL thật.',
 'fix':'Bổ sung dependency đọc trạng thái tài khoản hai phía hoặc policy chuyên trách; từ chối 403 nếu một bên bị khóa, trước khi trả liên hệ hoặc thực hiện ghi. Giữ unit kiểm cả trường hợp gia sư và bên học bị khóa khi sửa.'}

rows=[]
for c in cases:
    r=results[c['id']];n=int(c['id'][3:]);o=r['observations'][0]
    fail=failure175 if n==175 else failure179 if n==179 else None
    rows.append({'id':c['id'],'title':c['title'],'criterion':c['cells'][2],'designedTarget':c['cells'][4],'actualTarget':action(n),'arrangeFromWorkbook':c['cells'][6],
      'expected':c['cells'][9],'assertions':assertions(n),'outcome':r['outcome'],'actual':desc(o),'observations':r['observations'],
      'firstFailingAssertion':r['error'] or None,'stack':r['stack'] or None,'failure':fail,'applicationSource':source(n),'duration':r['duration']})
counts={x:sum(r['outcome']==x for r in rows) for x in ['Passed','Failed','NotExecuted']}

# Compare all earlier IDs with their existing result files; do not modify previous suites.
regroot=ET.parse('work/group07-regression/Regression-After-Group07.trx').getroot()
def id_results(xmlroot):
    d={}
    for r in xmlroot.findall('.//t:UnitTestResult',ns):
        m=re.search(r'UT[_-](\d+)',r.attrib['testName'])
        if m:d['UT-'+m.group(1).zfill(3)]=r.attrib['outcome']
    return d
reg=id_results(regroot);old={};oldfiles=[]
for f in sorted(Path('outputs').rglob('*.trx')):
    if '07-Service' in str(f):continue
    for id,status in id_results(ET.parse(f).getroot()).items():
        if int(id[3:])<170:old[id]=status
    oldfiles.append(str(f))
regression={'total':len(reg),'comparedPriorCases':len(old),'differences':[{'id':id,'previous':v,'current':reg.get(id)} for id,v in old.items() if reg.get(id)!=v],
            'priorSnapshotFiles':oldfiles,'wholeRunCounts':{x:sum(v==x for v in reg.values()) for x in set(reg.values())}}
assert len(reg)==220 and len(old)==169,regression
assert not regression['differences'],regression

data={'suite':'07. Service yêu cầu và đề xuất lớp','sourceWorkbook':r'C:\Users\NGUYEN THI YEN\Downloads\Unit Test.xlsx',
      'sheet':cases[0]['sheet'],'runTimes':root.find('t:Times',ns).attrib,'counts':counts,'testCases':51,'serviceInvocations':123,
      'unitScope':'Real KetNoiService, real ThongBaoService; strict mocks for persistence/current user/transaction/notice data; fixed service clock; no SQL Server or MVC pipeline.',
      'limitations':['UT-175–180 call the existing private four-argument AcceptedAsync via reflection; this is helper coverage, not public HTTP coverage.',
        'UT-203 injects SqlException 51152 at application-lock command boundary. Does not execute or prove negative sp_getapplock return handling in SQL.',
        'UT-211/217 inject DbUpdateConcurrencyException at Save and verify RV propagation; does not prove EF/SQL stale-row detection or database rollback.',
        'Success cases verify service commands, read-back mocks and pending notice/outbox before Save/Commit; do not prove actual stored procedure inserts, schedule rows or persisted atomicity.'],
      'regression':regression,'cases':rows}
(out/'KetQua.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copy2(trx,out/trx.name)

def esc(s):return str(s).replace('|','&#124;').replace('\n','<br>')
md=['# Kết quả 07. Service yêu cầu và đề xuất lớp','',
f"**51 ca UT-170–220: {counts['Passed']} Pass, {counts['Failed']} Fail, 0 Skip/Blocked.** Thực thi 123 lượt fixture/service: 48 ca chạy một lượt, ba ca ánh xạ SQL chạy 25 mã mỗi ca.",'',
'Nguồn kỳ vọng: `Unit Test.xlsx`, sheet `'+cases[0]['sheet']+'`. Giữ đúng mã và thứ tự trong file cập nhật. Ba tiêu chuẩn trong bảng gốc được giữ ở từng ca; các ca kiểm phiên/quyền thuộc xác thực, điều kiện/tham số/kết quả thuộc đúng đắn, nhánh lỗi và chống thiếu dữ liệu theo tiêu chuẩn đầy đủ của từng dòng. Báo cáo này không phải kết luận hệ thống đã đầy đủ mọi nhánh chỉ vì chạy hết 51 dòng.','',
'## Phạm vi và giới hạn của kết quả','',
'Service `KetNoiService` là đối tượng thật. Tầng đọc/ghi `IKetNoiStore`, nguồn người dùng `INguoiDungHienTaiService`, transaction và `IThongBaoData` dùng Moq strict. `ThongBaoService` thật tạo notice/outbox vào mock nhận dữ liệu. AppDbContext không cấu hình provider, không mở kết nối CSDL. Đồng hồ phục vụ điều kiện đề xuất/hết hạn cố định T=2026-11-14 03:00 UTC (10:00 UTC+7). Mỗi lượt có fixture và dữ liệu riêng.','',
'- UT-175–180 kiểm overload private `AcceptedAsync(Guid,bool,Guid,CancellationToken)` bằng reflection vì đó là helper đang có trong code và là đích của TC. Không tạo một bản helper khác trong test; không coi đây là kiểm endpoint public. Các ca khác gọi trực tiếp overload public tương ứng.','- UT-195/198/201 tạo SqlException thật về kiểu dữ liệu nhưng chỉ là exception giả lập trong bộ nhớ, lần lượt 51130–51154. Không gọi procedure.','- **UT-203:** Pass cho phần service nhận lỗi khóa 51152, trả 409 và dừng trước lệnh tạo lớp. Điều kiện “cổng khóa trả số âm” nằm trong chuỗi SQL thực thi; unit này không kiểm được việc SQL Server trả số âm rồi phát sinh 51152. Cần integration test cho phần đó.','- **UT-211/217:** Pass cho truyền RV0, xử lý exception concurrency tại Save và không Commit. Đối tượng theo dõi trong RAM đã đổi TuChoi/DaRut; không có dữ liệu được ghi xuống CSDL trong unit. Việc SQL phát hiện phiên bản cũ và rollback cần integration test.','- Ca tạo yêu cầu/đề xuất/lớp thành công chỉ xác nhận service phát đúng lệnh, đọc đúng kết quả giả lập, thêm notice/outbox và gọi Save trước Commit. Không xác nhận procedure đã tạo bản ghi lớp hoặc lịch học thực tế.','',
'Cách cô lập dependency và Arrange–Act–Assert dựa trên [Microsoft: unit testing best practices](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices) và mẫu mock dependency của [Microsoft: testing controller logic in ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/mvc/controllers/testing?view=aspnetcore-10.0). Việc gọi helper private bằng reflection là lựa chọn cụ thể cho TC này, không phải yêu cầu của Microsoft.','',
'## Hai ca thất bại','']
for id,fail in [('UT-175',failure175),('UT-179',failure179)]:
    r=next(r for r in rows if r['id']==id)
    md += [f"### {id} — {r['title']}",'',f"**Loại lỗi:** {fail['category']}.",'',f"**Dữ liệu và tái hiện:** {r['arrangeFromWorkbook']}",'',
      'Tạo fixture mới, giữ actor H là bên học, gọi helper thật qua overload có kiểm actor. '+('Cổng đọc liên hệ không có LH1 (Contact=null).' if id=='UT-175' else 'Contact LH1 có GiaSuId=G, BenHocId=H, TrangThai=ChapNhan; nguồn tài khoản giả lập có G.TrangThai=BiKhoa và H.HoatDong.'),'',
      f"**Kỳ vọng:** {r['expected']}",'',f"**Thực tế:** {r['actual']}",'', '**Sai lệch quan sát:**','']
    md += ['- '+d for d in fail['differences']]
    md += ['',f"**Assertion thất bại đầu tiên:** `{r['firstFailingAssertion'].strip().replace(chr(10),' / ')}`.",'',
      f"**Code liên quan:** `{fail['location']}`.",'',f"**Nguyên nhân:** {fail['cause']}",'',f"**Ảnh hưởng:** {fail['impact']}",'',f"**Đề xuất sửa:** {fail['fix']}",'']
md += ['## Kết quả từng ca','', '| Mã | Kịch bản | Tiêu chuẩn | Kết quả | Quan sát thực tế |','| --- | --- | --- | --- | --- |']
for r in rows:md.append('| '+' | '.join(esc(x) for x in [r['id'],r['title'],r['criterion'],'Pass' if r['outcome']=='Passed' else 'Fail',r['actual']])+ ' |')
md += ['','## Dữ liệu chung để tái hiện','',
'H/U1 (bên học)=`10000000-0000-0000-0000-000000000001`; G/U2 (gia sư)=`20000000-0000-0000-0000-000000000002`; người khác U3=`30000000-0000-0000-0000-000000000003`. LH1=`40000000-0000-0000-0000-000000000004`; YC1=`50000000-0000-0000-0000-000000000005`; C1=`60000000-0000-0000-0000-000000000006`.','',
'RV1=`[1,2,3,4,5,6,7,8]`, Base64=`AQIDBAUGBwg=`; RV0=`[0,0,0,0,0,0,0,1]`. Đề xuất mặc định: Toán lớp 9, MonHocId=1, mục tiêu Ôn tập, 1 buổi/tuần, 60 phút; thứ 2 từ 18:00–19:00; học phí 150000 VND/Gio; trực tuyến; bắt đầu 2026-11-15 10:00 UTC+7. Yêu cầu mặc định ChoBenHoc, gia sư là người gửi, hết hạn T+2 ngày.','',
'## Các bước thực thi và assertion theo từng ca','']
for r in rows:
    n=int(r['id'][3:]);o=r['observations'][0]
    md += [f"### {r['id']} — {r['title']} ({'Pass' if r['outcome']=='Passed' else 'Fail'})",'',
      f"- **Đích thiết kế:** `{r['designedTarget']}`.",f"- **Đích thực thi:** `{r['actualTarget']}`.",f"- **Tiêu chuẩn:** {r['criterion']}.",f"- **Dữ liệu riêng:** {r['arrangeFromWorkbook']}",
      '- **B1 – Arrange:** Khởi tạo `ServiceYeuCauDeXuatFixture` riêng. Dùng bộ ID/RV/đồng hồ ở trên; giữ service thật và mock cổng lưu trữ, người dùng, transaction, dữ liệu thông báo. Cấu hình predicate đọc trên bản ghi giả lập, không mock chính service đang kiểm.',
      '- **B2 – Cấu hình:** Áp dụng dữ liệu riêng của dòng này vào input/contact/request/tài khoản. Với lỗi SQL/concurrency, cổng giả lập ném đúng exception khi lệnh nghiệp vụ hoặc Save được gọi; không mở database.',
      f"- **B3 – Act:** `await {r['actualTarget']}` với actor/token của fixture. "+('Helper private được gọi qua reflection, await Task<KetQua<YeuCauLienHe>> thật.' if 175<=n<=180 else 'Ghi lại KetQua hoặc exception thoát ra, không mock kết quả này.'),
      f"- **B4 – Assert:** {r['assertions']}",
      '- **B5 – Bằng chứng:** Ghi `OBSERVATION_JSON` vào output của test trước assertion; TRX giữ trạng thái/stack, JSON giữ toàn bộ quan sát. Dispose fixture và transaction sau mỗi lượt.',
      f"- **Kỳ vọng từ Excel:** {r['expected']}",f"- **Thực tế:** {r['actual']}",f"- **Nguồn ứng dụng:** `{r['applicationSource']}`.",
      f"- **Chạy riêng:** `dotnet test tests/Unit/EduConnect.UnitTests.csproj --filter FullyQualifiedName~ServiceYeuCauDeXuatTest.UT_{n}`.",'']
    if len(r['observations'])>1:md += [f"Đã kiểm đủ {len(r['observations'])} mã SQL: "+', '.join(f"{o['sql']}→{o['actualStatus']}" for o in r['observations'])+'.','']

md += ['## File thêm và thay đổi','',
'- `tests/Unit/ServiceYeuCauDeXuatTest.cs`: 51 `[Fact]` có mã UT-170–220 và Trait Suite=ServiceYeuCauDeXuat.',
'- `tests/Unit/ServiceYeuCauDeXuatRunner.cs`: Arrange/Act/Assert riêng theo mã; ghi quan sát; ba ca SQL lặp đủ 25 mã.',
'- `tests/Unit/ServiceYeuCauDeXuatFixture.cs`: mock strict, ID/dữ liệu riêng, đồng hồ cố định, bắt lệnh/thông báo/outbox, tạo exception giả lập.',
'- `Areas/KetNoi/Services/IKetNoiStore.cs`: cổng đọc/ghi để thay dependency hạ tầng khi unit test.',
'- `Areas/KetNoi/Services/EfKetNoiStore.cs`: adapter EF mặc định giữ truy vấn/transaction/lệnh SQL trước đó.',
'- `KetNoiService.cs` và `KetNoiService.YeuCau.cs`: nhận store/TimeProvider tùy chọn; chuyển thao tác đọc/ghi qua adapter và dùng đồng hồ cho điều kiện thời gian. Không đổi guard nghiệp vụ, mã lỗi hay thuật toán để làm test Pass. Diff so với trước nhóm 07 nằm trong ZIP.',
'', '## Chạy lại trong VS Code','',
'Mở Terminal ở `C:/Khóa luận TN/Educonnect`. Bộ test đã được build và chạy với .NET SDK 10.0.403, target net10.0. Nếu có ứng dụng đang chạy và giữ DLL, dừng tiến trình đó hoặc dùng BaseOutputPath riêng như lệnh bên dưới. Không cần khởi động ứng dụng hay SQL Server để chạy nhóm này.','',
'```powershell',
'dotnet test tests/Unit/EduConnect.UnitTests.csproj --no-restore --filter "Suite=ServiceYeuCauDeXuat" -p:UseAppHost=false "-p:BaseOutputPath=$env:TEMP/EduConnect-Group07-Unit/" --logger "trx;LogFileName=Service-YeuCau-DeXuat-Lop-Unit.trx" --results-directory "TestResults/07-Service-YeuCau-DeXuat-Lop-Unit"',
'```','',
'Muốn chạy một ca, đổi filter thành `FullyQualifiedName~ServiceYeuCauDeXuatTest.UT_175`. Trong Test Explorer, chọn đúng lớp ServiceYeuCauDeXuatTest. Hai ca Fail hiện tại khiến `dotnet test` trả exit code 1; đây là thất bại assertion đã mô tả, không phải build bị lỗi.','',
'TRX là bằng chứng từ test runner; `KetQua.json` là bản đối chiếu chi tiết theo Excel; `KetQua.md` là bản đọc được có bảng và giải thích. Chạy lại lệnh chỉ cập nhật TRX; muốn đồng bộ MD/JSON cần chạy lại script báo cáo kèm trong ZIP với bản Excel/đường dẫn fixture tương ứng.','',
'## Kiểm tra hồi quy và tính nhất quán','',
f"Chạy lại toàn bộ project: {len(reg)} ca, 112 Pass, 105 Fail, 3 Skip. Đối chiếu {len(old)} ca UT-001–169 với các TRX đã có: **không ca nào đổi trạng thái**. Các Fail/Skip của nhóm cũ vẫn giữ nguyên; không tính chúng vào kết quả 51 ca nhóm 07. Log hồi quy chỉ lưu ở work, không ghi đè báo cáo cũ.",'',
'Đã xác nhận đủ 51 mã liên tiếp, mỗi mã một Fact; tổng dự án 220 mã duy nhất. Ba ca SQL có đủ 25 quan sát/mã. Bảng Markdown được kiểm số cột ở header, delimiter và từng dòng. SHA256 đi kèm để đối chiếu file kết quả và gói mã nguồn.','']
mdtext='\n'.join(md)
table=[s for s in mdtext.splitlines() if s.startswith('|')]
assert len(table)==53 and all(s.count('|')==6 for s in table)
(out/'KetQua.md').write_text(mdtext,encoding='utf-8')

# Capture only this task's two modified existing files as a patch, retaining prior work.
diff=[]
manifest=json.loads(Path('work/group07-manifest.json').read_text(encoding='utf-8'))
for path,sha in manifest.items():
    backup=Path('work/group07-backup')/path
    assert hashlib.sha256(backup.read_bytes()).hexdigest()==sha
    diff.extend(difflib.unified_diff(backup.read_text(encoding='utf-8-sig').splitlines(True),(repo/path).read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+path,tofile='after/'+path))
Path('work/group07-source.diff').write_text(''.join(diff),encoding='utf-8')
newfiles=['Areas/KetNoi/Services/IKetNoiStore.cs','Areas/KetNoi/Services/EfKetNoiStore.cs',
 'tests/Unit/ServiceYeuCauDeXuatTest.cs','tests/Unit/ServiceYeuCauDeXuatRunner.cs','tests/Unit/ServiceYeuCauDeXuatFixture.cs']
existing=list(manifest)+['Areas/KetNoi/Services/KetNoiService.KetThuc.cs','Areas/KetNoi/Services/IKetNoiService.cs','Infrastructure/KetQua.cs','Infrastructure/KetQuaKhongDuLieu.cs','Infrastructure/ThongBaoService.cs','Infrastructure/IThongBaoData.cs','Infrastructure/INguoiDungHienTaiService.cs','Infrastructure/BusinessRules.cs','tests/Unit/EduConnect.UnitTests.csproj','Areas/KetNoi/ViewModels/KetNoiInput.cs']
with zipfile.ZipFile(out/'Ma_nguon_Unit.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in newfiles+existing:
        if (repo/path).exists():z.write(repo/path,path)
    for path in manifest:z.write(Path('work/group07-backup')/path,'before-group07/'+path)
    z.write('work/group07-source.diff','group07-source.diff')
    z.write('work/report_group07.py','report_group07.py')
    z.write('work/group07-cases.json','inputs/group07-cases.json')
    for f in out.iterdir():
        if f.suffix in ('.md','.json','.trx') and f.name!='SHA256.json':z.write(f,'results/'+f.name)
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in out.iterdir() if f.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps({'counts':counts,'observations':123,'regression':regression,'output':str(out.resolve())},ensure_ascii=False,indent=2))

