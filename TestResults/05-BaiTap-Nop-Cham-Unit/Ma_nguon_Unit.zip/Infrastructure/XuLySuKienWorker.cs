using System.Text.Json;
using EduConnect.Mvc.Areas.HocTap.Services;
using EduConnect.Mvc.Data;
using EduConnect.Mvc.Models;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace EduConnect.Mvc.Infrastructure;

public sealed class XuLySuKienWorker(IServiceScopeFactory scopes, IHubContext<CapNhatThoiGianThucHub> hub,
    PhienCapNhat phien, ILogger<XuLySuKienWorker> log) : BackgroundService
{
    private DateTimeOffset lanKiemTraQuyen;
    protected override async Task ExecuteAsync(CancellationToken token)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(500));
        while (!token.IsCancellationRequested)
        {
            try
            {
                phien.DonDep();
                await XuLySuKienDenHanAsync(32, token);
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested) { break; }
            catch (Exception ex) { log.LogWarning(ex, "Chưa xử lý xong cập nhật; sẽ thử lại."); }
            try { if (!await timer.WaitForNextTickAsync(token)) break; }
            catch (OperationCanceledException) { break; }
        }
    }
    public async Task XuLySuKienDenHanAsync(int soLuong, CancellationToken token)
    {
        soLuong = Math.Clamp(soLuong, 1, 100);
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var messages = scope.ServiceProvider.GetRequiredService<TinNhanService>();
        var sessions = scope.ServiceProvider.GetRequiredService<PhienDangNhapService>();
        if (DateTimeOffset.UtcNow - lanKiemTraQuyen > TimeSpan.FromSeconds(5))
        {
            await KiemTraKetNoiAsync(messages, sessions, token);
            lanKiemTraQuyen = DateTimeOffset.UtcNow;
        }
        var lease = Guid.NewGuid();
        // A single atomic UPDATE claims committed rows. Expired leases can be recovered after a crash.
        List<SuKienChoXuLy> events;
        await using (var claim = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadCommitted, token))
        {
        events = await db.Set<SuKienChoXuLy>().FromSqlInterpolated($"""
            ;WITH viec AS (
              SELECT TOP ({soLuong}) * FROM dbo.SuKienChoXuLy WITH (UPDLOCK, READPAST, READCOMMITTEDLOCK)
              WHERE (TrangThai IN ('ChoXuLy','ChoThuLai') AND (ThuLaiLuc IS NULL OR ThuLaiLuc<=SYSDATETIMEOFFSET()))
                 OR (TrangThai='DangXuLy' AND LeaseHetHanLuc<=SYSDATETIMEOFFSET())
              ORDER BY TaoLuc,Id
            )
            UPDATE viec SET TrangThai='DangXuLy',LeaseId={lease},
              LeaseHetHanLuc=DATEADD(second,60,SYSDATETIMEOFFSET()),SoLanThu=SoLanThu+1
            OUTPUT inserted.*;
            """).AsNoTracking().ToListAsync(token);
        await claim.CommitAsync(token);
        }
        foreach (var ev in events)
        {
            await OutboxDelivery.RunAsync(ev, token,
                async () =>
                {
                var owned = await db.Database.ExecuteSqlInterpolatedAsync($"""
                    UPDATE dbo.SuKienChoXuLy SET LeaseHetHanLuc=DATEADD(second,60,SYSDATETIMEOFFSET())
                    WHERE Id={ev.Id} AND LeaseId={lease} AND TrangThai='DangXuLy' AND LeaseHetHanLuc>SYSDATETIMEOFFSET()
                    """, token);
                    return owned != 0;
                },
                () => PhatCapNhatAsync(ev, db, messages, sessions, token),
                async () =>
                {
                await db.Database.ExecuteSqlInterpolatedAsync($"""
                    UPDATE dbo.SuKienChoXuLy SET TrangThai='HoanTat',XuLyXongLuc=SYSDATETIMEOFFSET(),
                      ThuLaiLuc=NULL,LeaseId=NULL,LeaseHetHanLuc=NULL WHERE Id={ev.Id} AND LeaseId={lease}
                    """, token);
                },
                async seconds =>
                {
                await db.Database.ExecuteSqlInterpolatedAsync($"""
                    UPDATE dbo.SuKienChoXuLy SET TrangThai='ChoThuLai',ThuLaiLuc=DATEADD(second,{seconds},SYSDATETIMEOFFSET()),
                      LeaseId=NULL,LeaseHetHanLuc=NULL WHERE Id={ev.Id} AND LeaseId={lease}
                    """, token);
                },
                ex => log.LogWarning(ex, "Không phát được sự kiện {EventId}; sẽ thử lại.", ev.Id));
        }
    }

    private async Task KiemTraKetNoiAsync(TinNhanService messages, PhienDangNhapService sessions, CancellationToken token)
    {
        foreach (var c in phien.DanhSach())
        {
            if (!phien.HopLe(c) || !Guid.TryParse(c.PhienId, out var session)
                || !await sessions.HopLeAsync(session, c.Nguoi, false, token))
            { phien.Xoa(c.Id, true); continue; }
            foreach (var room in c.HoiThoai.Keys)
            {
                try { await messages.KiemTraAsync(room, c.Nguoi); }
                catch (LoiNghiepVu)
                {
                    c.HoiThoai.TryRemove(room, out _);
                    await hub.Groups.RemoveFromGroupAsync(c.Id, c.NhomHoiThoai(room), token);
                }
            }
        }
    }
    private async Task PhatCapNhatAsync(SuKienChoXuLy ev, AppDbContext db, TinNhanService messages, PhienDangNhapService sessions, CancellationToken token)
    {
        using var json = JsonDocument.Parse(ev.DuLieuToiThieu);
        var data = json.RootElement;
        var target = data.GetProperty("target").GetGuid();
        var room = ev.LoaiSuKien == "TinNhan" ? data.GetProperty("room").GetGuid() : (Guid?)null;
        var recipient = room == null ? data.GetProperty("recipient").GetGuid() : (Guid?)null;
        foreach (var c in phien.DanhSach())
        {
            if (!phien.HopLe(c)) { phien.Xoa(c.Id, true); continue; }
            if (room.HasValue ? !c.HoiThoai.ContainsKey(room.Value) : c.Nguoi != recipient) continue;
            if (!Guid.TryParse(c.PhienId, out var session)
                || !await sessions.HopLeAsync(session, c.Nguoi, false, token))
            { phien.Xoa(c.Id, true); continue; }
            if (room.HasValue)
            {
                try { await messages.KiemTraAsync(room.Value, c.Nguoi); }
                catch (LoiNghiepVu)
                {
                    c.HoiThoai.TryRemove(room.Value, out _);
                    await hub.Groups.RemoveFromGroupAsync(c.Id, c.NhomHoiThoai(room.Value), token);
                    continue;
                }
            }
            if (!phien.HopLe(c)) { phien.Xoa(c.Id, true); continue; }
            // Each group is scoped to a connection so stale permissions cannot inherit a broad broadcast.
            var group = room.HasValue ? c.NhomHoiThoai(room.Value) : c.NhomCaNhan;
            await hub.Clients.Group(group).SendAsync("CapNhat", new { maSuKien = ev.Id, loai = ev.LoaiSuKien, doiTuongId = target, hoiThoaiId = room }, token);
        }
        // Successful transport dispatch is not a delivery/read receipt. Offline users reload from SQL.
    }
}
